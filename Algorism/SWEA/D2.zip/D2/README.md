# 📑D2_개념 정리 

```python
# 항목별 개수 세기
from collections import Counter

ans = Counter(<순회가능>).items() # 딕셔너리로 뽑아내기
>> dict_items([(91, 10), (78, 10), ...])
```
