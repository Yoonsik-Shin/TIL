import math

a, b = map(int,input().split())

print(a+b)
print(a-b)
print(a*b)
print(math.trunc(a/b))