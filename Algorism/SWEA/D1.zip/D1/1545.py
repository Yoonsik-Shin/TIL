# import sys
# sys.stdin = open('./Algorism/SWEA/level1/SampleInput.txt','r')

number = int(input())

for i in range(number,-1,-1):
    print(i, end=' ')