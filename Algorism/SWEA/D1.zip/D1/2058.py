N = int(input())
N_str = str(N)
ans = 0

for i in N_str:
    ans += int(i)

print(ans)