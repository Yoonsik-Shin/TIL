# 📑D1_개념 정리 

```python
# 소수점 자리 버리기
import math

print(math.trunc())		
```

```python
# 테스트 케이스 파일 실행하기
import sys
sys.stdin = open('<경로>', 'r')
```

