from statistics import median

N = int(input())
lst = list(map(int,input().split()))
print(median(lst))