x = input()
ans = x.upper()
print(ans)