P, K = map(int,input().split())

print(P-K+1)